# NextKDE「开机只剩壁纸」修复文件包

- 生成时间：2026-11-04
- 对应仓库提交：`3631ffc7`（main）
- 内容：仅本次桌面故障所涉及的修复文件，不含全量源码、`.git`、`.build`、Notes 功能改动及任何 `.bak` 备份

## 故障原因

`kosctl install` 会把 `~/.config/plasmashellrc` 切成 `ShellPackage=org.kos.desktop`，这个 shell 包按设计只渲染壁纸；顶栏、Dock 等全部 UI 由 Quickshell 的 `kos-shell.service` 提供。

源码树中 8 个 git 符号链接被物化成了空目录，`deploy_artifacts` 只补了 `shared/qml/controls` 和 `Kos/Ui/*`，没有补 `shell/shared/qml/i18n` 与 `foundation`，于是安装产物里这两个模块是空目录，Quickshell 报：

```
@desktop/DesktopEnvironment.qml[5:1]: module "../shared/qml/i18n" is not installed
```

`kos-shell.service` 每 2 秒崩溃重启，界面那一半始终没起来，就只剩 plasmashell 画的壁纸。

> 注意：仓库 `3631ffc7` 里这些文件本来就存在，修复只是把被破坏的符号链接**恢复原状**，所以修复完成后 `git status` 是干净的 —— 这个包用于「在另一处应用修复」，不是可直接提交的 commit 内容。若要给 GitHub main 提交一个真正的改动，需要给 `kosctl` 增加部署后的 QML 模块完整性校验。

## 包内容

| 路径 | 说明 | 数量 |
|---|---|---|
| `symlinks/shell/shared/qml/{controls,foundation,i18n}` | 3 个符号链接，目标 `../../../shared/qml/*` | 3 |
| `symlinks/shell/Kos/Ui/{colorize,controls,foundation,i18n,wallpapers}` | 5 个符号链接，目标同上 | 5 |
| `qml-modules/shared/qml/i18n/` | `qmldir`、`I18n.qml`、`ZhCatalog.mjs`、`PtBrCatalog.mjs`、`SystemLanguage.mjs` | 5 |
| `qml-modules/shared/qml/foundation/` | `qmldir` 及 34 个 QML/JS/MJS 文件 | 35 |
| `SHA256SUMS` | 40 个模块文件的校验和 | 1 |
| `README.md` | 本说明 | 1 |

合计 8 个符号链接 + 42 个普通文件。两个模块与本机 `~/.config/quickshell/kos/shared/qml/` 中已补齐的内容逐文件一致。

链接目标 `../../../shared/qml/*` 是**相对于项目根下 `shell/shared/qml/` 位置**写的，因此刚解压到 `symlinks/` 下时它们显示为断开状态，属正常；按下面方式 B 复制回项目根后即恢复有效。

## 应用方式

**A. 根本修复（推荐，仓库完好时）**

```bash
cd /home/louyve/NextKde
git checkout -f -- shell/shared/qml shell/Kos/Ui
git status --short                 # 应无输出
./tools/kosctl install
./tools/kosctl start
```

**B. 没有 git 仓库时用本包恢复链接**

```bash
FIX=/解压目录/NextKDE-fix-20261104
PROJ=/home/louyve/NextKde
cd "$FIX/symlinks"
find . -type l | while read -r l; do
  dst="${l#./}"
  rm -rf "$PROJ/$dst"
  mkdir -p "$PROJ/$(dirname "$dst")"
  cp -a "$l" "$PROJ/$dst"
done
cd "$PROJ" && ./tools/kosctl install && ./tools/kosctl start
```

**C. 只想让当前会话立刻恢复界面（临时，下次 install 会被覆盖）**

```bash
FIX=/解压目录/NextKDE-fix-20261104
cp -a "$FIX/qml-modules/shared/qml/i18n/."       ~/.config/quickshell/kos/shared/qml/i18n/
cp -a "$FIX/qml-modules/shared/qml/foundation/." ~/.config/quickshell/kos/shared/qml/foundation/
systemctl --user restart kos-shell.service
```

## 解压与校验

```bash
tar -xzf NextKDE-fix-20261104.tar.gz -C <目标目录>
tar -tzvf NextKDE-fix-20261104.tar.gz | grep ' -> '   # 应输出 8 行
cd NextKDE-fix-20261104 && LC_ALL=C sha256sum -c SHA256SUMS   # 40 项应全部 OK
```

`LC_ALL=C` 是为了让输出固定为 `OK`；中文 locale 下 `sha256sum` 会输出「成功」，含义相同。

**只提供 tar.gz，不提供 zip**：符号链接正是这次修复的核心，多数 zip 解压器（尤其 Windows 下）会把它写成普通文件或空目录，等于把故障一起打包进去。GNU tar 默认完整保留链接及其相对目标。
